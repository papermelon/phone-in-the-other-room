<?php
/** Public invitation handoff. Never resolves private party details on the web. */
add_action('template_redirect', function () {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    if ($path === '/.well-known/apple-app-site-association' || $path === '/apple-app-site-association') {
        status_header(200);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        echo wp_json_encode(array('applinks' => array('details' => array(array(
            'appIDs' => array('4KZQPZR47B.com.ngawangchime.countingsheep'),
            'components' => array(array('/' => '/invite/*', 'comment' => 'Review a Slumber Party invitation')),
        )))));
        exit;
    }
    if (!is_string($path) || strpos($path, '/invite/') !== 0) {
        return;
    }
    $valid = preg_match('#^/invite/([A-HJ-NP-Z2-9]{12})$#D', $path, $match) === 1;
    status_header($valid ? 200 : 404);
    if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    header('Referrer-Policy: no-referrer');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    $code = $valid ? $match[1] : '';
    $cta = cs_get_app_primary_cta();
    ?>
    <!doctype html>
    <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="referrer" content="no-referrer"><meta name="robots" content="noindex,nofollow">
    <title>Slumber Party invitation · Counting Sheep</title>
    <style>
      :root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#294457;color:#e2d1b3;font:18px/1.55 system-ui,sans-serif;min-height:100vh;display:grid;place-items:center;padding:24px}
      main{width:min(100%,560px)}h1{font-size:clamp(28px,7vw,40px);line-height:1.15;color:#fff}p{margin:1em 0}code{display:block;overflow-wrap:anywhere;font:600 22px/1.5 ui-monospace,monospace;letter-spacing:.1em;padding:16px;border:1px solid currentColor;border-radius:8px}
      a,button{color:inherit}a.button,button{font:inherit;display:inline-block;min-height:44px;padding:12px 18px;border-radius:8px;border:1px solid #e2d1b3;margin:8px 8px 8px 0;cursor:pointer;text-decoration:none;background:transparent}.primary{background:#e2d1b3!important;color:#294457}a:focus-visible,button:focus-visible{outline:3px solid white;outline-offset:4px}.small{font-size:15px}
    </style></head><body><main>
      <p>Counting Sheep</p><h1><?php echo $valid ? 'You’re invited to a Slumber Party' : 'This invitation link is incomplete'; ?></h1>
      <?php if ($valid) : ?>
      <p>A private group for you and people you know. Open Counting Sheep to review the invitation and decide whether to join.</p>
      <a class="button primary" href="<?php echo esc_url('countingsheep://invite/' . $code, array('countingsheep')); ?>">Open Counting Sheep</a>
      <p>Or enter this invitation code in the app:</p><code id="invite-code"><?php echo esc_html($code); ?></code>
      <button type="button" id="copy-code">Copy code</button><span id="copy-status" role="status" aria-live="polite"></span>
      <p class="small">After installing, return to this link or use the code. The app checks whether the invitation is still available. Opening it doesn’t join the party or enable sharing.</p>
      <?php else : ?>
      <p>Ask the person inviting you for the complete link or the 12-character code.</p>
      <?php endif; ?>
      <p><a href="<?php echo esc_url($cta['url']); ?>" rel="noreferrer"><?php echo esc_html($cta['label']); ?></a></p>
      <p class="small"><a href="<?php echo esc_url(home_url('/')); ?>">About Counting Sheep</a></p>
    </main>
    <?php if ($valid) : ?>
    <script>
      document.getElementById('copy-code').addEventListener('click', async () => {
        const code = document.getElementById('invite-code').textContent;
        try { await navigator.clipboard.writeText(code); document.getElementById('copy-status').textContent = 'Code copied.'; }
        catch { document.getElementById('copy-status').textContent = 'Select and copy the code above.'; }
      });
    </script>
    <?php endif; ?>
    </body></html>
    <?php
    exit;
}, 0);
