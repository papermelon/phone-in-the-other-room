<?php
/*
Template Name: All Posts
*/
get_header();
?>

<main id="main-content" class="all-posts-page" role="main">

    <section class="resource-hero" aria-labelledby="resources-page-title">
        <div class="resource-hero-inner">
            <div>
                <p class="cs-kicker">Resources</p>
                <h1 id="resources-page-title">Small ideas for better nights.</h1>
                <p>Recognise the habits that shape sleep, understand what is happening, and try something practical—without turning bedtime into homework.</p>
            </div>
            <picture class="resource-hero-sheep cs-bramble">
                <source srcset="<?php echo esc_url(get_template_directory_uri() . '/assets/sheep-bramble.webp'); ?>" type="image/webp">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/sheep-bramble.png'); ?>"
                    alt="" width="512" height="512">
            </picture>
        </div>
    </section>

    <section class="all-posts">
        <div class="posts-filter-form">
            <div class="search-wrapper">
                <label class="visually-hidden" for="search-posts">Search resources</label>
                <input type="text" id="search-posts" placeholder="Search posts...">
                <button type="button" id="search-icon" aria-label="Search">
                    <span class="dashicons dashicons-search"></span>
                </button>
            </div>

            <label class="visually-hidden" for="filter-date">Filter resources by date</label>
            <select id="filter-date">
                <option value="">All Dates</option>
                <?php
                global $wpdb;
                $months = $wpdb->get_results("
            SELECT DISTINCT YEAR(post_date) AS year, MONTH(post_date) AS month 
            FROM $wpdb->posts 
            WHERE post_type='post' AND post_status='publish' 
            ORDER BY post_date DESC
        ");
                foreach ($months as $m) :
                    $month = zeroise($m->month, 2);
                    $value = $m->year . $month;
                    $label = date("F Y", mktime(0, 0, 0, $m->month, 1, $m->year));
                    echo "<option value='$value'>$label</option>";
                endforeach;
                ?>
            </select>
        </div>

        <div class="posts-container" id="posts-results">
            <!-- Results will be injected here -->
        </div>

    </section>

    <!-- Brochure Modal -->
    <div id="brochure-modal" class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" hidden>
        <div class="modal-content brochure-modal">
            <button type="button" class="close" aria-label="Close brochure">&times;</button>
            <div class="brochure-left">
                <button class="brochure-nav-arrow prev" aria-label="Previous image">&#10094;</button>

                <div class="brochure-image-slider">
                    <!-- Images will be injected here later -->
                    <img class="slide active" src="" alt="Brochure image">
                </div>

                <button class="brochure-nav-arrow next" aria-label="Next image">&#10095;</button>
            </div>

            <div class="brochure-right">
                <h3 id="modal-title"></h3>
                <p id="modal-text"></p>
            </div>
        </div>
    </div>

</main>

<?php get_footer(); ?>
