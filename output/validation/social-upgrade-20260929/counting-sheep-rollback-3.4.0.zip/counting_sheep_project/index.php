<?php
get_header();

$app_cta = cs_get_app_primary_cta();
$release_form_id = cs_get_release_signup_form_id();
$testflight_url = get_theme_mod('csp_app_testflight_url', 'https://testflight.apple.com/join/yq1TqH9z');
$resources_url = get_permalink(get_page_by_path('all-posts')) ?: home_url('/all-posts/');
$about_url = get_permalink(get_page_by_path('about-us')) ?: home_url('/about-us/');
$instagram_url = 'https://www.instagram.com/countingsheepproject/';
$theme_assets = get_template_directory_uri() . '/assets';

$app_screens = array(
    array(
        'file' => 'app-home-wind-down',
        'label' => 'Home',
        'alt' => 'Counting Sheep Home showing the Wind Down schedule and Start Wind Down button',
        'width' => 1206,
        'height' => 2622,
    ),
    array(
        'file' => 'app-wind-down',
        'label' => 'Wind Down',
        'alt' => 'Counting Sheep Wind Down with Ollie on the Moonlit Trail and a sleep-time countdown',
        'width' => 470,
        'height' => 1024,
    ),
    array(
        'file' => 'app-farm',
        'label' => 'The Farm',
        'alt' => 'Counting Sheep Farm showing a pasture, Ollie, and wool from Wind Down',
        'width' => 517,
        'height' => 1024,
    ),
);

$community_images = array();
for ($section = 1; $section <= 3; $section++) {
    for ($image_index = 1; $image_index <= 3; $image_index++) {
        $image_url = get_theme_mod("csp_about_{$section}_img{$image_index}");
        $image_caption = get_theme_mod("csp_about_{$section}_cap{$image_index}");

        if ($image_url) {
            $community_images[] = array(
                'url' => $image_url,
                'alt' => $image_caption ?: 'Counting Sheep community workshop',
            );
        }
    }
}

if (!$community_images) {
    $community_images = array(
        array('url' => $theme_assets . '/about1.jpg', 'alt' => 'Counting Sheep community activity'),
        array('url' => $theme_assets . '/about2.jpg', 'alt' => 'Counting Sheep workshop'),
        array('url' => $theme_assets . '/about3.jpg', 'alt' => 'Counting Sheep community event'),
    );
}
?>

<main id="main-content" class="home-story" role="main">
    <section class="cs-hero" aria-labelledby="hero-title">
        <div class="cs-shell cs-hero-grid">
            <div class="cs-hero-copy">
                <p class="cs-kicker">Designing better sleep through play</p>
                <h1 id="hero-title">Put your phone to bed.<br><em>Wake up before it does.</em></h1>
                <p class="cs-hero-lede">
                    Counting Sheep is a playful phone-away app that helps you spend less time on screens in the moments around sleep—before bed and after waking.
                    <?php echo $app_cta['state'] === 'launched' ? 'Available for iPhone.' : ($app_cta['state'] === 'beta' ? 'Try the iPhone beta on TestFlight.' : 'Currently in development for iPhone.'); ?>
                </p>
                <div class="cs-actions" aria-label="App introduction">
                    <a class="cs-button cs-button-primary" href="#app">Meet the app</a>
                    <a class="cs-text-link" href="#how-it-works">See how it works <span aria-hidden="true">↓</span></a>
                </div>
                <p class="cs-prelaunch-note"><span aria-hidden="true"></span>
                    <?php echo $app_cta['state'] === 'launched' ? 'Now available on the App Store' : ($app_cta['state'] === 'beta' ? 'TestFlight beta · Still in development' : 'Pre-launch · Building in the open'); ?>
                </p>
            </div>

            <div class="cs-hero-product" aria-label="A preview of the Counting Sheep app">
                <div class="cs-orbit cs-orbit-one" aria-hidden="true"></div>
                <div class="cs-orbit cs-orbit-two" aria-hidden="true"></div>
                <div class="cs-phone cs-phone-hero">
                    <div class="cs-phone-speaker" aria-hidden="true"></div>
                    <picture>
                        <source srcset="<?php echo esc_url($theme_assets . '/app-home-wind-down.webp'); ?>" type="image/webp">
                        <img src="<?php echo esc_url($theme_assets . '/app-home-wind-down.png'); ?>"
                            alt="Counting Sheep Home with a Wind Down schedule, 30 phone-free minutes before bed and after waking, and Ollie’s welcome"
                            width="1206" height="2622" fetchpriority="high">
                    </picture>
                </div>
                <picture class="cs-hero-sheep cs-bramble">
                    <source srcset="<?php echo esc_url($theme_assets . '/sheep-bramble.webp'); ?>" type="image/webp">
                    <img src="<?php echo esc_url($theme_assets . '/sheep-bramble.png'); ?>" alt="Bramble, a cream-coloured sheep with a green neckerchief" width="512" height="512">
                </picture>
                <p class="cs-scribble cs-scribble-hero">Time to wind down</p>
            </div>
        </div>
        <div class="cs-fence-run" aria-hidden="true">
            <img class="sheep cs-jump-sheep" src="<?php echo esc_url($theme_assets . '/sheep.gif'); ?>" alt=""
                width="500" height="500">
            <picture class="cs-fence-picture">
                <source srcset="<?php echo esc_url($theme_assets . '/fence.webp'); ?>" type="image/webp">
                <img src="<?php echo esc_url($theme_assets . '/fence.png'); ?>" alt="">
            </picture>
        </div>
    </section>

    <section class="cs-tension" aria-labelledby="tension-title">
        <div class="cs-shell cs-narrow">
            <p class="cs-kicker">The 12:30am problem</p>
            <h2 id="tension-title">You probably don’t need another sleep tip.</h2>
            <div class="cs-tension-grid">
                <p class="cs-big-copy">You already know “one more scroll” rarely means one more scroll.</p>
                <div>
                    <p>The hard part is not knowing what to do. It is doing it in the moment—when the bed is warm, the feed keeps moving, and tomorrow feels far away.</p>
                    <p>Counting Sheep is exploring a gentler bridge between intention and action: make putting the phone away feel like the start of something, not a punishment.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="app" class="cs-app-intro" aria-labelledby="app-title">
        <div class="cs-shell cs-app-intro-grid">
            <div class="cs-app-sticky">
                <div class="cs-app-gallery" data-cs-gallery>
                    <div class="cs-phone cs-phone-detail">
                        <div class="cs-phone-speaker" aria-hidden="true"></div>
                        <div class="cs-app-gallery-viewport" id="cs-app-gallery-viewport" role="region" aria-roledescription="carousel" aria-label="Counting Sheep app screenshots">
                            <ul class="cs-app-gallery-track">
                                <?php foreach ($app_screens as $index => $screen) : ?>
                                    <li class="cs-app-gallery-slide" data-label="<?php echo esc_attr($screen['label']); ?>" <?php echo $index === 0 ? '' : 'aria-hidden="true"'; ?>>
                                        <picture>
                                            <source srcset="<?php echo esc_url($theme_assets . '/' . $screen['file'] . '.webp'); ?>" type="image/webp">
                                            <img src="<?php echo esc_url($theme_assets . '/' . $screen['file'] . '.png'); ?>"
                                                alt="<?php echo esc_attr($screen['alt']); ?>"
                                                width="<?php echo (int) $screen['width']; ?>"
                                                height="<?php echo (int) $screen['height']; ?>"
                                                loading="lazy">
                                        </picture>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="cs-app-gallery-controls">
                        <button type="button" class="cs-app-gallery-btn cs-app-gallery-prev" aria-controls="cs-app-gallery-viewport" aria-label="Previous screenshot">
                            <span aria-hidden="true">‹</span>
                        </button>
                        <div class="cs-app-gallery-dots" role="group" aria-label="Choose a screenshot">
                            <?php foreach ($app_screens as $index => $screen) : ?>
                                <button type="button" class="cs-app-gallery-dot" data-index="<?php echo (int) $index; ?>" aria-label="<?php echo esc_attr(sprintf('Show %s screenshot', $screen['label'])); ?>" aria-current="<?php echo $index === 0 ? 'true' : 'false'; ?>"></button>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" class="cs-app-gallery-btn cs-app-gallery-next" aria-controls="cs-app-gallery-viewport" aria-label="Next screenshot">
                            <span aria-hidden="true">›</span>
                        </button>
                    </div>
                    <p class="cs-app-gallery-caption" aria-live="polite">
                        <span class="cs-app-gallery-caption-label"><?php echo esc_html($app_screens[0]['label']); ?></span>
                        <span class="cs-app-gallery-caption-count">1 of <?php echo count($app_screens); ?></span>
                    </p>
                </div>
            </div>
            <div class="cs-app-copy">
                <p class="cs-kicker">Meet the app</p>
                <h2 id="app-title">Less screen time before bed. Less screen time after waking.</h2>
                <p class="cs-lead">Choose a realistic phone-free window before bed and after waking. Leave your phone in another room, then let the app keep a simple record of the time you protected.</p>
                <p class="cs-product-language"><strong>In the app, this is Wind Down:</strong> a small, repeatable screen habit designed to make more room for winding down, waking gently, and sleeping well.</p>

                <div id="how-it-works" class="cs-steps">
                    <article class="cs-step">
                        <span class="cs-step-number" aria-hidden="true">01</span>
                        <div>
                            <h3>Choose when screens go away</h3>
                            <p>Pick how long you want to be phone-free before bed and after waking.</p>
                        </div>
                    </article>
                    <article class="cs-step">
                        <span class="cs-step-number" aria-hidden="true">02</span>
                        <div>
                            <h3>Leave the phone in another room</h3>
                            <p>Start the session and put it somewhere you will not reach for without thinking.</p>
                        </div>
                    </article>
                    <article class="cs-step">
                        <span class="cs-step-number" aria-hidden="true">03</span>
                        <div>
                            <h3>Begin and end the night off-screen</h3>
                            <p>Wind down without scrolling. In the morning, give yourself a little time before the feed starts.</p>
                        </div>
                    </article>
                    <article class="cs-step">
                        <span class="cs-step-number" aria-hidden="true">04</span>
                        <div>
                            <h3>Track the habit you’re building</h3>
                            <p>See the phone-free time you protected, notice what you repeat, and build a steadier screen routine around sleep.</p>
                        </div>
                    </article>
                </div>

                <div class="cs-actions cs-app-actions">
                    <a class="cs-button cs-button-dark" href="<?php echo esc_url($app_cta['url']); ?>"
                        <?php echo $app_cta['external'] ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
                        <?php echo esc_html($app_cta['label']); ?>
                    </a>
                    <span class="cs-status">
                        <?php
                        if ($app_cta['state'] === 'launched') {
                            echo esc_html__('Available on the App Store', 'counting-sheep');
                        } elseif ($app_cta['state'] === 'beta') {
                            echo esc_html__('iPhone beta · Requires TestFlight', 'counting-sheep');
                        } elseif ($app_cta['state'] === 'early-access') {
                            echo esc_html__('Private early access', 'counting-sheep');
                        } else {
                            echo esc_html__('Not yet on the App Store', 'counting-sheep');
                        }
                        ?>
                    </span>
                </div>
                <nav class="cs-app-help-links" aria-label="App updates and help">
                    <?php if ($app_cta['state'] !== 'launched') : ?>
                        <a href="#app-updates"><?php echo $release_form_id ? 'Email me at launch' : 'Release updates'; ?></a>
                    <?php endif; ?>
                    <?php if ($testflight_url) : ?>
                        <a href="#beta-feedback">How to share beta feedback</a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </section>

    <section class="cs-flock-break" aria-labelledby="flock-title">
        <div class="cs-shell cs-flock-break-grid">
            <div>
                <p class="cs-kicker">Counting sheep, differently</p>
                <h2 id="flock-title">Let the sheep do the counting.</h2>
                <p>They keep the world playful and the goal simple: a little less screen, a little more room for sleep. No lecture. No anti-phone guilt. No need to be perfect.</p>
            </div>
            <div class="cs-flock-lineup" aria-hidden="true">
                <picture>
                    <source srcset="<?php echo esc_url($theme_assets . '/sheep-mabel.webp'); ?>" type="image/webp">
                    <img class="cs-wool-art" src="<?php echo esc_url($theme_assets . '/sheep-mabel.png'); ?>" alt="" width="512" height="512" loading="lazy">
                </picture>
                <picture>
                    <source srcset="<?php echo esc_url($theme_assets . '/sheep-bramble.webp'); ?>" type="image/webp">
                    <img class="cs-bramble-art" src="<?php echo esc_url($theme_assets . '/sheep-bramble.png'); ?>" alt="" width="512" height="512" loading="lazy">
                </picture>
                <picture>
                    <source srcset="<?php echo esc_url($theme_assets . '/sheep-pippin.webp'); ?>" type="image/webp">
                    <img class="cs-wool-art" src="<?php echo esc_url($theme_assets . '/sheep-pippin.png'); ?>" alt="" width="512" height="512" loading="lazy">
                </picture>
            </div>
        </div>
    </section>

    <section class="cs-ecosystem" aria-labelledby="ecosystem-title">
        <div class="cs-shell">
            <div class="cs-section-heading">
                <p class="cs-kicker">The wider Counting Sheep world</p>
                <h2 id="ecosystem-title">Understanding helps.<br>Experience makes it real.<br><em>Practice makes it yours.</em></h2>
            </div>
            <div class="cs-ecosystem-path" aria-label="How Counting Sheep’s work fits together">
                <article>
                    <span>Understand</span>
                    <h3>Small ideas for better nights</h3>
                    <p>Useful, approachable content helps us notice what is happening around sleep and screens.</p>
                    <a class="cs-text-link" href="<?php echo esc_url($resources_url); ?>">Explore resources <span aria-hidden="true">→</span></a>
                </article>
                <article>
                    <span>Experience</span>
                    <h3>Try it together</h3>
                    <p>Workshops and community events create space to reflect, make, play, and talk honestly about our habits.</p>
                    <a class="cs-text-link" href="#community">See community work <span aria-hidden="true">↓</span></a>
                </article>
                <article class="is-primary">
                    <span>Practise</span>
                    <h3>Bring the habit home</h3>
                    <p>The app turns one intention—spend less time on your phone around sleep—into a repeatable nightly ritual.</p>
                    <a class="cs-text-link" href="#app">Meet the app <span aria-hidden="true">↑</span></a>
                </article>
            </div>
        </div>
    </section>

    <section id="community" class="cs-community" aria-labelledby="community-title">
        <div class="cs-shell">
            <div class="cs-community-grid">
                <div class="cs-community-copy">
                    <p class="cs-kicker">Workshops &amp; community</p>
                    <h2 id="community-title">Better nights are easier to imagine together.</h2>
                    <p>We run playful, participatory experiences around sleep, screens, and everyday wellbeing—with communities, schools, workplaces, and collaborators.</p>
                    <div class="cs-actions">
                        <button class="cs-button cs-button-dark contact-cta-btn" aria-haspopup="dialog" aria-controls="dynamic-form-modal">Partner with us</button>
                        <a class="cs-text-link" href="<?php echo esc_url($about_url); ?>">About Counting Sheep <span aria-hidden="true">→</span></a>
                    </div>
                </div>
                <div class="cs-photo-collage" aria-label="Counting Sheep workshops and community events">
                    <?php foreach (array_slice($community_images, 0, 3) as $image_number => $community_image) : ?>
                        <figure class="cs-community-photo cs-community-photo-<?php echo (int) $image_number + 1; ?>">
                            <img src="<?php echo esc_url($community_image['url']); ?>"
                                alt="<?php echo esc_attr($community_image['alt']); ?>" loading="lazy">
                        </figure>
                    <?php endforeach; ?>
                    <p class="cs-photo-note">Real conversations.<br>Small experiments.<br>Plenty of making.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="cs-resources" aria-labelledby="resources-title">
        <div class="cs-shell">
            <div class="cs-resource-header">
                <div>
                    <p class="cs-kicker">Ideas to take into tonight</p>
                    <h2 id="resources-title">Small ideas for better nights.</h2>
                </div>
                <a class="cs-text-link" href="<?php echo esc_url($resources_url); ?>">See all resources <span aria-hidden="true">→</span></a>
            </div>

            <div class="posts-container cs-resource-grid">
                <?php
                $latest_posts = new WP_Query(array(
                    'posts_per_page' => 3,
                    'post_status' => 'publish',
                ));

                if ($latest_posts->have_posts()) :
                    while ($latest_posts->have_posts()) :
                        $latest_posts->the_post();
                        $type = get_post_meta(get_the_ID(), 'post_type', true);
                        $brochure_images = array();
                        for ($i = 1; $i <= 10; $i++) {
                            $image_id = get_post_meta(get_the_ID(), "brochure_image_$i", true);
                            if ($image_id) {
                                $image_url = wp_get_attachment_url($image_id);
                                if ($image_url) {
                                    $brochure_images[] = $image_url;
                                }
                            }
                        }
                        $link = get_post_meta(get_the_ID(), 'post_link', true);
                        $thumbnail = has_post_thumbnail()
                            ? get_the_post_thumbnail_url(get_the_ID(), 'large')
                            : $theme_assets . '/logo_icon.png';
                        ?>
                        <article class="post-card" role="button" tabindex="0"
                            data-id="<?php echo (int) get_the_ID(); ?>"
                            data-slug="<?php echo esc_attr(sanitize_title(get_the_title())); ?>"
                            data-type="<?php echo esc_attr($type); ?>"
                            data-link="<?php echo esc_url($link); ?>"
                            data-brochure-images="<?php echo esc_attr(wp_json_encode($brochure_images)); ?>"
                            data-content="<?php echo esc_attr(apply_filters('the_content', get_post_field('post_content', get_the_ID()))); ?>"
                            itemscope itemtype="https://schema.org/BlogPosting">
                            <div class="cs-post-image">
                                <img src="<?php echo esc_url($thumbnail); ?>" alt="" itemprop="image" loading="lazy">
                            </div>
                            <p class="cs-post-type"><?php echo esc_html($type ?: 'From Counting Sheep'); ?></p>
                            <h3 itemprop="headline"><?php the_title(); ?></h3>
                            <p itemprop="description"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 18, '…')); ?></p>
                            <span class="cs-card-link">Read more <span aria-hidden="true">→</span></span>
                            <meta itemprop="url" content="<?php the_permalink(); ?>">
                            <meta itemprop="datePublished" content="<?php echo esc_attr(get_the_date('c')); ?>">
                            <meta itemprop="author" content="Counting Sheep Project">
                        </article>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    ?>
                    <p>New resources are on their way.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="cs-support" aria-labelledby="support-title">
        <div class="cs-shell cs-support-grid">
            <div>
                <p class="cs-kicker">Community-backed</p>
                <h2 id="support-title">Made with support.<br>Built with people.</h2>
                <p>Counting Sheep’s work has grown through real community activity and support from organisations that believe in young people and wellbeing.</p>
            </div>
            <div class="sponsors-container">
                <?php
                $sponsors = array(
                    array(
                        'name' => 'National Youth Council',
                        'logo' => 'https://isomer-user-content.by.gov.sg/139/218fed0b-dfd3-408b-921d-22eee54dce86/NYC_2025_Logo_RGB.png',
                        'url' => 'https://www.nyc.gov.sg/',
                    ),
                    array(
                        'name' => 'Humanistic Youth Council',
                        'logo' => 'https://hyc.tzuchi.org.sg/media/images/HYC_Logo_trans.original.png',
                        'url' => 'https://hyc.tzuchi.org.sg/',
                    ),
                    array(
                        'name' => 'Singapore Association of Social Workers',
                        'logo' => 'https://sasw.org.sg/wp-content/uploads/2020/12/sasw-logo.png',
                        'url' => 'https://sasw.org.sg/',
                    ),
                    array(
                        'name' => 'Youth Action Challenge Season 5',
                        'logo' => 'https://countingsheepproject.com/wp-content/uploads/2025/03/YAC-Season-5-Logo.png',
                        'url' => 'https://www.nyc.gov.sg/key-initiatives/youth-action-challenge',
                    ),
                );

                foreach ($sponsors as $sponsor) :
                    ?>
                    <a href="<?php echo esc_url($sponsor['url']); ?>" target="_blank" rel="noopener noreferrer" class="sponsor-card">
                        <img src="<?php echo esc_url($sponsor['logo']); ?>"
                            alt="<?php echo esc_attr($sponsor['name']); ?>" loading="lazy">
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="cs-final-cta" aria-labelledby="final-cta-title">
        <div class="cs-shell cs-final-cta-inner">
            <picture class="cs-final-sheep cs-bramble">
                <source srcset="<?php echo esc_url($theme_assets . '/sheep-bramble.webp'); ?>" type="image/webp">
                <img src="<?php echo esc_url($theme_assets . '/sheep-bramble.png'); ?>" alt="" width="512" height="512" loading="lazy">
            </picture>
            <div>
                <p class="cs-kicker"><?php echo $app_cta['state'] === 'launched' ? 'Make room off-screen' : 'We’re still building'; ?></p>
                <?php if ($app_cta['state'] === 'launched') : ?>
                    <h2 id="final-cta-title">Ready to put your phone to bed?</h2>
                    <p>Start a more screen-free ritual around sleep with a little help from the flock.</p>
                <?php elseif ($app_cta['state'] === 'beta') : ?>
                    <h2 id="final-cta-title">Better nights, built together.<br><em>Come try the beta.</em></h2>
                    <p>Try Counting Sheep on iPhone through TestFlight and help shape a more playful relationship with screens around sleep. This is a work in progress, not the finished App Store release.</p>
                <?php else : ?>
                    <h2 id="final-cta-title">The app isn’t ready to download.<br><em>The idea is ready to follow.</em></h2>
                    <p>Come along as we test, learn, and shape a more playful way to put the phone down around sleep.</p>
                <?php endif; ?>
                <div class="cs-actions">
                    <a class="cs-button cs-button-primary" href="<?php echo esc_url($app_cta['url']); ?>"
                        <?php echo $app_cta['external'] ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
                        <?php echo esc_html($app_cta['label']); ?>
                    </a>
                    <a class="cs-text-link" href="<?php echo esc_url($instagram_url); ?>" target="_blank" rel="noopener noreferrer">@countingsheepproject <span aria-hidden="true">↗</span></a>
                </div>
            </div>
        </div>
    </section>

    <?php if ($app_cta['state'] !== 'launched' || $testflight_url) : ?>
        <section class="cs-app-support" aria-label="Stay involved with the app">
            <div class="cs-shell cs-app-support-grid">
                <?php if ($app_cta['state'] !== 'launched') : ?>
                    <section id="app-updates" aria-labelledby="app-updates-title">
                        <p class="cs-kicker">Not a beta person? That’s okay.</p>
                        <h2 id="app-updates-title">A little nudge<br>when we launch.</h2>
                        <?php if ($release_form_id) : ?>
                            <p>Leave your email and we’ll let you know when Counting Sheep arrives on the App Store. No need to join the beta.</p>
                            <div class="cs-release-form">
                                <?php echo do_shortcode('[forminator_form id="' . $release_form_id . '"]'); ?>
                            </div>
                            <p class="cs-support-note">Your email is for the release announcement, not a general mailing list. Changed your mind? <button type="button" class="cs-inline-contact contact-cta-btn" aria-haspopup="dialog" aria-controls="dynamic-form-modal">Ask us to remove your signup.</button></p>
                        <?php else : ?>
                            <p>Email signups aren’t open here yet. For now, follow Counting Sheep on Instagram for release news and glimpses of what we’re building.</p>
                            <a class="cs-text-link" href="<?php echo esc_url($instagram_url); ?>" target="_blank" rel="noopener noreferrer">Follow release news <span aria-hidden="true">↗</span></a>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <?php if ($testflight_url) : ?>
                    <section id="beta-feedback" aria-labelledby="beta-feedback-title">
                        <p class="cs-kicker">Already trying the beta?</p>
                        <h2 id="beta-feedback-title">Tell us what<br>your night was like.</h2>
                        <p>Something confusing? Something you loved? A button that did absolutely nothing? We’d like to hear it.</p>
                        <ol class="cs-feedback-steps">
                            <li>Open <strong>TestFlight</strong> on your iPhone and choose <strong>Counting Sheep</strong>.</li>
                            <li>Tap <strong>Send Beta Feedback</strong>. Add a screenshot if it helps, or choose not to include one.</li>
                            <li>Tell us what happened, then tap <strong>Submit</strong>.</li>
                        </ol>
                        <details class="cs-feedback-details">
                            <summary>What makes useful feedback?</summary>
                            <p>For a bug: what you did, what you expected, and what happened instead. Include your iPhone model, iOS version and app build if you know them.</p>
                            <p>For everything else: did putting your phone away feel easier? What got in the way before bed or after waking? Small observations are useful too.</p>
                            <p>Leave private messages, health details and other people’s information out of screenshots. Feedback sent through TestFlight is shared with Apple and the app developer.</p>
                        </details>
                        <p class="cs-support-note">Can’t use TestFlight feedback? <button type="button" class="cs-inline-contact contact-cta-btn" aria-haspopup="dialog" aria-controls="dynamic-form-modal">Contact us instead.</button> Sending feedback does not sign you up for release emails.</p>
                        <a class="cs-text-link" href="<?php echo esc_url($testflight_url); ?>" target="_blank" rel="noopener noreferrer">Open the beta invitation <span aria-hidden="true">↗</span></a>
                    </section>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <div id="brochure-modal" class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" hidden>
        <div class="modal-content brochure-modal">
            <button type="button" class="close" aria-label="Close resource">&times;</button>
            <div class="brochure-left">
                <button class="brochure-nav-arrow prev" aria-label="Previous image">&#10094;</button>
                <div class="brochure-image-slider">
                    <img class="slide active" src="" alt="Resource image">
                </div>
                <button class="brochure-nav-arrow next" aria-label="Next image">&#10095;</button>
            </div>
            <div class="brochure-right">
                <h3 id="modal-title"></h3>
                <div id="modal-text"></div>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
