<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <?php
    $cs_meta_description = is_front_page()
        ? 'Counting Sheep is designing better sleep through play, with a phone-away app, workshops and community experiences for healthier sleep and screen habits.'
        : (is_singular() ? wp_strip_all_tags(get_the_excerpt()) : get_bloginfo('description'));
    ?>
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="<?php echo is_singular() ? 'article' : 'website'; ?>" />
    <meta property="og:title" content="<?php echo wp_get_document_title(); ?>" />
    <meta property="og:description" content="<?php echo esc_attr($cs_meta_description); ?>" />
    <meta property="og:url" content="<?php echo esc_url(cs_get_canonical_url()); ?>" />
    <meta property="og:site_name" content="<?php bloginfo('name'); ?>" />

    <?php if (is_singular() && has_post_thumbnail()) : ?>
        <meta property="og:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" />
    <?php else : ?>
        <meta property="og:image" content="<?php echo esc_url(get_template_directory_uri() . '/assets/logo_with_text.png'); ?>" />
    <?php endif; ?>

    <!-- Twitter -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo wp_get_document_title(); ?>" />
    <meta name="twitter:description" content="<?php echo esc_attr($cs_meta_description); ?>" />

    <?php if (is_singular() && has_post_thumbnail()) : ?>
        <meta name="twitter:image" content="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'large')); ?>" />
    <?php else : ?>
        <meta name="twitter:image" content="<?php echo esc_url(get_template_directory_uri() . '/assets/logo_with_text.png'); ?>" />
    <?php endif; ?>


    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO: Meta description -->
    <meta name="description" content="<?php echo esc_attr($cs_meta_description); ?>">

    <!-- SEO: Canonical URL -->
    <link rel="canonical" href="<?php echo esc_url(cs_get_canonical_url()); ?>">

    <!-- Favicons (recommended for SEO + branding) -->
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/assets/favicon.ico" type="image/x-icon">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <a class="skip-link" href="#main-content">Skip to content</a>
    <header class="navbar" role="banner">
        <div class="navbar-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/logo_with_text.png"
                    alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
            </a>
        </div>

        <nav id="primary-navigation" class="navbar-links" role="navigation" aria-label="Main Navigation">
            <ul class="navbar-links-list">
                <li><a href="<?php echo esc_url(home_url('/#app')); ?>">App</a></li>
                <li><a href="<?php echo esc_url(home_url('/#community')); ?>">Workshops</a></li>
                <li><a href="<?php echo esc_url(get_permalink(get_page_by_path('all-posts')) ?: home_url('/all-posts/')); ?>">Resources</a></li>
                <li><a href="<?php echo esc_url(get_permalink(get_page_by_path('about-us')) ?: home_url('/about-us/')); ?>">About</a></li>
            </ul>
        </nav>

        <a class="navbar-cta" href="<?php echo esc_url(cs_get_app_primary_cta()['url']); ?>"
            <?php echo cs_get_app_primary_cta()['external'] ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
            <?php echo esc_html(cs_get_app_primary_cta()['label']); ?>
        </a>
        <button class="navbar-toggle" aria-label="Open menu" aria-controls="primary-navigation" aria-expanded="false">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </button>
    </header>
