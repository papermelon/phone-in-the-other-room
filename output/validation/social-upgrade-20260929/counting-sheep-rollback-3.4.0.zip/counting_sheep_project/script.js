document.addEventListener("DOMContentLoaded", () => {
    // ---------- Scroll-responsive sheep-and-fence moment ----------
    const sheep = document.querySelector(".cs-jump-sheep");
    const fenceRun = document.querySelector(".cs-fence-run");
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (sheep && fenceRun && !reduceMotion) {
        let animationFrame = null;

        const updateSheep = () => {
            // Preserve the original site's three-part motion: run-up, jump, run-out.
            const runUpScroll = 50;
            const jumpScroll = 120;
            const runOutScroll = 200;
            const totalScroll = runUpScroll + jumpScroll + runOutScroll;
            const animationStart = fenceRun.offsetTop - window.innerHeight * 0.84;
            const scroll = Math.max(0, Math.min(totalScroll, window.scrollY - animationStart));
            const distanceScale = Math.min(1, Math.max(0.42, (window.innerWidth - 80) / 620));
            const runUpLength = 150 * distanceScale;
            const jumpLength = 170 * distanceScale;
            const runOutLength = 300 * distanceScale;
            const jumpHeight = (window.innerWidth <= 520 ? 96 : 150) * distanceScale;
            let x = 0;
            let y = 0;

            if (scroll <= runUpScroll) {
                const t = scroll / runUpScroll;
                x = t * runUpLength;
            } else if (scroll <= runUpScroll + jumpScroll) {
                const t = (scroll - runUpScroll) / jumpScroll;
                x = runUpLength + t * jumpLength;
                y = -4 * jumpHeight * (t - 0.5) * (t - 0.5) + jumpHeight;
            } else {
                const t = (scroll - runUpScroll - jumpScroll) / runOutScroll;
                x = runUpLength + jumpLength + t * runOutLength;
            }

            sheep.style.transform = `translate3d(${x}px, ${-y}px, 0)`;
            sheep.style.zIndex = scroll > runUpScroll + jumpScroll * 0.8 ? "1" : "3";
            sheep.classList.toggle("happy", scroll > runUpScroll + jumpScroll * 0.95);
            animationFrame = null;
        };

        const requestSheepUpdate = () => {
            if (animationFrame !== null) return;
            animationFrame = window.requestAnimationFrame(updateSheep);
        };

        window.addEventListener("scroll", requestSheepUpdate, { passive: true });
        window.addEventListener("resize", requestSheepUpdate);
        updateSheep();
    }

    // ---------- Mobile hamburger toggle ----------
    const toggle = document.querySelector(".navbar-toggle");
    if (toggle) {
        toggle.addEventListener("click", () => {
            const isOpen = document.body.classList.toggle("nav-open");
            toggle.setAttribute("aria-expanded", String(isOpen));
            toggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
        });

        document.querySelectorAll("#primary-navigation a").forEach(link => {
            link.addEventListener("click", () => {
                document.body.classList.remove("nav-open");
                toggle.setAttribute("aria-expanded", "false");
                toggle.setAttribute("aria-label", "Open menu");
            });
        });
    }

    // ---------- App screenshot gallery (no autoplay) ----------
    document.querySelectorAll("[data-cs-gallery]").forEach((gallery) => {
        const viewport = gallery.querySelector(".cs-app-gallery-viewport");
        const slides = Array.from(gallery.querySelectorAll(".cs-app-gallery-slide"));
        const prevBtn = gallery.querySelector(".cs-app-gallery-prev");
        const nextBtn = gallery.querySelector(".cs-app-gallery-next");
        const dots = Array.from(gallery.querySelectorAll(".cs-app-gallery-dot"));
        const captionLabel = gallery.querySelector(".cs-app-gallery-caption-label");
        const captionCount = gallery.querySelector(".cs-app-gallery-caption-count");

        if (!viewport || slides.length === 0) return;

        const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        let index = 0;

        const slideWidth = () => viewport.clientWidth;

        const goTo = (nextIndex, instant = false) => {
            index = (nextIndex + slides.length) % slides.length;
            viewport.scrollTo({
                left: index * slideWidth(),
                behavior: instant || reduceMotion ? "auto" : "smooth"
            });
            updateChrome();
        };

        const updateChrome = () => {
            slides.forEach((slide, slideIndex) => {
                if (slideIndex === index) {
                    slide.removeAttribute("aria-hidden");
                } else {
                    slide.setAttribute("aria-hidden", "true");
                }
            });
            dots.forEach((dot, dotIndex) => {
                dot.setAttribute("aria-current", slideIndexCurrent(dotIndex));
            });
            if (captionLabel) {
                captionLabel.textContent = slides[index].dataset.label || "";
            }
            if (captionCount) {
                captionCount.textContent = `${index + 1} of ${slides.length}`;
            }
        };

        const slideIndexCurrent = (dotIndex) => (dotIndex === index ? "true" : "false");

        const syncFromScroll = () => {
            const width = slideWidth();
            if (!width) return;
            const nextIndex = Math.round(viewport.scrollLeft / width);
            if (nextIndex !== index && nextIndex >= 0 && nextIndex < slides.length) {
                index = nextIndex;
                updateChrome();
            }
        };

        prevBtn?.addEventListener("click", () => goTo(index - 1));
        nextBtn?.addEventListener("click", () => goTo(index + 1));
        dots.forEach((dot) => {
            dot.addEventListener("click", () => {
                const target = Number(dot.dataset.index);
                if (Number.isInteger(target)) goTo(target);
            });
        });

        gallery.addEventListener("keydown", (event) => {
            if (!gallery.contains(document.activeElement)) return;
            if (event.key === "ArrowLeft") {
                event.preventDefault();
                goTo(index - 1);
            } else if (event.key === "ArrowRight") {
                event.preventDefault();
                goTo(index + 1);
            } else if (event.key === "Home") {
                event.preventDefault();
                goTo(0);
            } else if (event.key === "End") {
                event.preventDefault();
                goTo(slides.length - 1);
            }
        });

        viewport.addEventListener("scroll", () => {
            window.requestAnimationFrame(syncFromScroll);
        }, { passive: true });

        window.addEventListener("resize", () => goTo(index, true));
        updateChrome();
    });

    // === Universal Carousel Script (handles multiple instances) ===
    document.querySelectorAll(".about-carousel").forEach(carousel => {
        const track = carousel.querySelector(".carousel-track");
        const images = carousel.querySelectorAll(".carousel-track img");
        const prevBtn = carousel.querySelector(".carousel-btn.prev");
        const nextBtn = carousel.querySelector(".carousel-btn.next");

        if (!track || images.length === 0) return;

        let index = 0;
        const total = images.length;
        let intervalId;

        const updateCarousel = () => {
            track.style.transform = `translateX(-${index * 100}%)`;
        };

        const nextSlide = () => {
            index = (index + 1) % total;
            updateCarousel();
        };

        const prevSlide = () => {
            index = (index - 1 + total) % total;
            updateCarousel();
        };

        const startAutoSlide = () => {
            intervalId = setInterval(nextSlide, 5000);
        };

        const resetAutoSlide = () => {
            clearInterval(intervalId);
            startAutoSlide();
        };

        // --- Button controls ---
        if (nextBtn) nextBtn.addEventListener("click", () => { nextSlide(); resetAutoSlide(); });
        if (prevBtn) prevBtn.addEventListener("click", () => { prevSlide(); resetAutoSlide(); });

        // --- Auto-start ---
        startAutoSlide();
    });

    let scrollPosition = 0;
    // ---------- Contact / Dynamic Form Modal ----------
    const formModal = document.getElementById('dynamic-form-modal');
    const formCloseBtn = formModal?.querySelector('.close');
    const formTitle = document.getElementById('form-title');
    const contactBtn = document.querySelector('.contact-us-btn');
    const contactCtaBtns = document.querySelectorAll('.contact-cta-btn');
    let formModalTrigger = null;

    function getFocusableElements(container) {
        return Array.from(container.querySelectorAll(
            'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )).filter(element => !element.hidden && element.offsetParent !== null);
    }

    // Open modal when contact button is clicked
    if (contactBtn) {
        contactBtn.addEventListener('click', openFormModal);
    }
    contactCtaBtns.forEach(button => button.addEventListener('click', openFormModal));

    // Open modal
    function openFormModal() {
        if (!formModal || !formTitle) return;
        formModalTrigger = document.activeElement;
        formTitle.textContent = "Contact Us";
        formModal.hidden = false;
        formModal.style.display = 'block';
        // Save current scroll position
        scrollPosition = window.scrollY;

        // Freeze the background but keep visual position
        document.body.style.position = 'fixed';
        document.body.style.top = `-${scrollPosition}px`;
        document.body.style.left = '0';
        document.body.style.right = '0';
        requestAnimationFrame(() => {
            const focusableElements = getFocusableElements(formModal);
            focusableElements[0]?.focus();
        });
    }

    function closeFormModal() {
        if (!formModal) return;
        formModal.style.display = 'none';
        formModal.hidden = true;
        resetScrollModalClose();
        formModalTrigger?.focus();
    }

    if (formCloseBtn) {
        formCloseBtn.addEventListener('click', closeFormModal);
    }

    function resetScrollModalClose() {
        // Restore scroll
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.left = '';
        document.body.style.right = '';
        window.scrollTo(0, scrollPosition);
    }

    // Close modal when background is clicked
    if (formModal) {
        formModal.addEventListener('click', e => {
            if (e.target === formModal) {
                closeFormModal();
            }
        });

        formModal.addEventListener('keydown', event => {
            if (event.key === 'Escape') {
                event.preventDefault();
                closeFormModal();
                return;
            }

            if (event.key !== 'Tab') return;
            const focusableElements = getFocusableElements(formModal);
            if (!focusableElements.length) return;
            const first = focusableElements[0];
            const last = focusableElements[focusableElements.length - 1];

            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });
    }


    let currentBrochureImageIndex = 0;
    let totalSlides = 0;
    let brochureModalTrigger = null;
    // ---------- Post card load for sharing ----------
    function checkBrochureHash() {
        const hash = window.location.hash;
        if (hash.startsWith("#brochure=")) {
            const param = hash.replace("#brochure=", "");
            const parts = param.split("-");
            const postId = parts[parts.length - 1];

            const card = document.querySelector(`.post-card[data-id='${postId}']`);
            if (card) {
                const title = card.querySelector("h3")?.textContent || "";
                const text = card.dataset.content || "";
                const images = JSON.parse(card.dataset.brochureImages || "[]");
                openBrochureModal(images, title, text);
            } else {
                // If posts aren't loaded yet, try again after 300ms
                setTimeout(checkBrochureHash, 300);
            }
        }
    }
    checkBrochureHash();


    // ---------- Brochure Modal ----------
    function openBrochureModal(images = [], title = "", text = "") {
        const modal = document.getElementById('brochure-modal');
        if (!modal) return;
        const slider = modal.querySelector('.brochure-image-slider');
        const modalTitle = document.getElementById('modal-title');
        const modalText = document.getElementById('modal-text');

        //hide arrow if only 1 image
        const prevArrow = modal.querySelector('.brochure-nav-arrow.prev');
        const nextArrow = modal.querySelector('.brochure-nav-arrow.next');

        if (images.length <= 1) {
            prevArrow.style.display = 'none';
            nextArrow.style.display = 'none';
        } else {
            prevArrow.style.display = 'flex';
            nextArrow.style.display = 'flex';
        }


        if (!modal || !slider || !modalTitle || !modalText) return;

        currentBrochureImageIndex = 0;
        totalSlides = images.length;

        // Save current scroll position
        scrollPosition = window.scrollY;

        // Freeze the background but keep visual position
        document.body.style.position = 'fixed';
        document.body.style.top = `-${scrollPosition}px`;
        document.body.style.left = '0';
        document.body.style.right = '0';

        slider.innerHTML = images.map((src, index) => `
            <img class="slide ${index === 0 ? 'active' : ''}" src="${src}" alt="Brochure image ${index + 1}">
        `).join('');


        modal.hidden = false;
        modal.style.display = 'flex';
        modalTitle.textContent = title;
        modalText.innerHTML = text;
        requestAnimationFrame(() => modal.querySelector('.close')?.focus());
    }


    // ---------- Post card clicks ----------
    function attachPostCardListeners() {
        const postCards = document.querySelectorAll(".post-card");
        postCards.forEach(card => {
            if (card.dataset.listenerAttached === "true") return;
            card.dataset.listenerAttached = "true";

            const openPostCard = function () {
                const type = this.dataset.type;
                const link = this.dataset.link;
                const images = JSON.parse(this.dataset.brochureImages || "[]");
                const title = this.querySelector("h3")?.textContent || "";
                const text = this.dataset.content || "";

                if (type === "link" && link) {
                    window.open(link, "_blank");
                } else if (type === "brochure" && images) {
                    brochureModalTrigger = this;
                    const postId = this.getAttribute("data-id");
                    const slug = this.dataset.slug;
                    openBrochureModal(images, title, text);

                    // Update URL (slug + ID for uniqueness)
                    const encodedSlug = encodeURIComponent(slug);
                    history.pushState({ brochure: postId }, "", `#brochure=${encodedSlug}-${postId}`);
                }
            };

            card.addEventListener("click", openPostCard);
            card.addEventListener("keydown", function (event) {
                if (event.key !== "Enter" && event.key !== " ") return;
                event.preventDefault();
                openPostCard.call(this);
            });
        });
    }

    attachPostCardListeners();
    // ---------- Post card close ----------
    const brochureModal = document.getElementById('brochure-modal');
    if (brochureModal) {
        const closeBtn = brochureModal.querySelector('.close');

        const closeBrochureModal = () => {
            brochureModal.style.display = 'none';
            brochureModal.hidden = true;
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.left = '';
            document.body.style.right = '';
            window.scrollTo(0, scrollPosition);
            history.replaceState({}, "", window.location.pathname);
            brochureModalTrigger?.focus();
        };

        if (closeBtn) {
            closeBtn.addEventListener('click', closeBrochureModal);
        }

        brochureModal.addEventListener('click', e => {
            if (e.target === brochureModal) {
                closeBrochureModal();
            }
        });

        brochureModal.addEventListener('keydown', event => {
            if (event.key === 'Escape') {
                event.preventDefault();
                closeBrochureModal();
                return;
            }

            if (event.key !== 'Tab') return;
            const focusableElements = getFocusableElements(brochureModal);
            if (!focusableElements.length) return;
            const first = focusableElements[0];
            const last = focusableElements[focusableElements.length - 1];

            if (event.shiftKey && document.activeElement === first) {
                event.preventDefault();
                last.focus();
            } else if (!event.shiftKey && document.activeElement === last) {
                event.preventDefault();
                first.focus();
            }
        });
    }


    // ---------- image navigation ----------
    document.querySelector('.brochure-nav-arrow.prev')?.addEventListener('click', e => {
        e.stopPropagation();
        showSlide(currentBrochureImageIndex - 1);
    });

    document.querySelector('.brochure-nav-arrow.next')?.addEventListener('click', e => {
        e.stopPropagation();
        showSlide(currentBrochureImageIndex + 1);
    });

    function showSlide(index) {
        const slides = document.querySelectorAll('.brochure-image-slider .slide');
        if (!slides.length) return;

        const prevIndex = currentBrochureImageIndex;
        currentBrochureImageIndex = (index + slides.length) % slides.length;

        slides.forEach((slide, i) => {
            if (i === currentBrochureImageIndex) {
                slide.classList.add('active'); // fade in
            } else if (i === prevIndex) {
                slide.classList.remove('active'); // fade out
            } else {
                slide.classList.remove('active');
            }
        });
    }



    //for mobile swiping
    let startX = 0;
    const slider = document.querySelector('.brochure-image-slider');
    if (slider) {
        slider.addEventListener('touchstart', e => {
            startX = e.touches[0].clientX;
        });

        slider.addEventListener('touchend', e => {
            const endX = e.changedTouches[0].clientX;
            const diff = startX - endX;

            if (Math.abs(diff) > 50) {
                if (diff > 0) {
                    showSlide(currentBrochureImageIndex + 1); // swipe left
                } else {
                    showSlide(currentBrochureImageIndex - 1); // swipe right
                }
            }
        });
    }



    const searchInput = document.getElementById("search-posts");
    const dateSelect = document.getElementById("filter-date");
    const results = document.getElementById("posts-results");

    // ---------- all posts page ----------
    if (searchInput && dateSelect && results) {
        function fetchPosts() {
            const search = searchInput.value;
            const date = dateSelect.value;

            const formData = new FormData();
            formData.append("action", "cs_filter_posts");
            formData.append("search", search);
            formData.append("date", date);

            fetch(cs_ajax.ajax_url, {
                method: "POST",
                body: formData
            })
                .then(res => res.text())
                .then(data => {
                    results.innerHTML = data;
                    checkBrochureHash();
                    attachPostCardListeners();
                });
        }

        // Live search with delay
        let searchTimeout;
        searchInput.addEventListener("input", () => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(fetchPosts, 500);
        });
        dateSelect.addEventListener("change", fetchPosts);

        // Initial load
        fetchPosts();
    }

    // ---------- floating particles on about us page ----------
    const floatingParticlesContainer = document.getElementById("floating-particles");
    if (floatingParticlesContainer) {
        // Generate a random number between 8 and 20
        const PARTICLE_COUNT = Math.floor(Math.random() * (20 - 8 + 1)) + 8;

        for (let i = 0; i < PARTICLE_COUNT; i++) {
            const particle = document.createElement("span");

            // Random size (10px–60px)
            const size = Math.floor(Math.random() * 50) + 10;
            particle.style.width = size + "px";
            particle.style.height = size + "px";

            // Random starting position (0%–100%)
            particle.style.top = Math.random() * 100 + "%";
            particle.style.left = Math.random() * 100 + "%";

            // Random animation duration (8–20 seconds)
            particle.style.setProperty("--duration", (8 + Math.random() * 12) + "s");


            // Random color variation within brand accent family
            const colors = [
                "var(--theme-accent)",
                "var(--theme-purple6)",
                "rgba(255,255,255,0.8)"
            ];
            particle.style.background = colors[Math.floor(Math.random() * colors.length)];

            floatingParticlesContainer.appendChild(particle);
        }
    }

    const searchIcon = document.getElementById("search-icon");
    // ---------- search icon ----------
    if (searchIcon && searchInput) {
        searchIcon.addEventListener("click", () => {
            // Only on mobile — hide keyboard
            if (window.innerWidth <= 768) {
                searchInput.blur(); // hides keyboard
            }
        });
    }

});
