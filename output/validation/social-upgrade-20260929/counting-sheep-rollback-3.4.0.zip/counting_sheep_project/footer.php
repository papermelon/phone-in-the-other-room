<footer class="site-footer" role="contentinfo" aria-label="Site Footer">
    <div class="footer-container">
        <div class="footer-brand">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/logo_with_text.png"
                    alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
            </a>
            <p>Designing better sleep through play.</p>
        </div>

        <nav class="footer-nav" aria-label="Footer navigation">
            <div>
                <h2>Explore</h2>
                <a href="<?php echo esc_url(home_url('/#app')); ?>">The app</a>
                <a href="<?php echo esc_url(home_url('/#community')); ?>">Workshops</a>
                <a href="<?php echo esc_url(get_permalink(get_page_by_path('all-posts')) ?: home_url('/all-posts/')); ?>">Resources</a>
                <a href="<?php echo esc_url(get_permalink(get_page_by_path('about-us')) ?: home_url('/about-us/')); ?>">About us</a>
            </div>
            <div>
                <h2>Keep in touch</h2>
                <?php if (cs_get_app_primary_cta()['state'] !== 'launched') : ?>
                    <a href="<?php echo esc_url(home_url('/#app-updates')); ?>">App release updates</a>
                <?php endif; ?>
                <?php if (get_theme_mod('csp_app_testflight_url', 'https://testflight.apple.com/join/yq1TqH9z')) : ?>
                    <a href="<?php echo esc_url(home_url('/#beta-feedback')); ?>">Beta feedback guide</a>
                <?php endif; ?>
                <a href="https://www.instagram.com/countingsheepproject/" target="_blank" rel="noopener noreferrer">Instagram</a>
                <a href="https://www.linkedin.com/company/counting-sheep-project" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                <button class="contact-us-btn" aria-haspopup="dialog" aria-controls="dynamic-form-modal">Contact us</button>
            </div>
            <div>
                <h2>More</h2>
                <a href="https://shopee.sg/countingsheepproject" target="_blank" rel="noopener noreferrer">Shop</a>
                <a href="https://linktr.ee/countingsheep.sg" target="_blank" rel="noopener noreferrer">All links</a>
            </div>
        </nav>

        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Counting Sheep Project.</p>
            <p>A community initiative from Singapore.</p>
        </div>
    </div>

</footer>

<!-- Dynamic Form Modal -->
<div id="dynamic-form-modal" class="modal" role="dialog" aria-modal="true" aria-labelledby="form-title" hidden>
    <div class="modal-content form-modal">
        <button type="button" class="close" aria-label="Close contact form">&times;</button>
        <h2 id="form-title">RSVP / Contact</h2>

        <div class="forminator-form-wrapper">
            <?php echo do_shortcode('[forminator_form id="4325"]'); ?>
        </div>

        <p id="form-message"></p>
    </div>
</div>


<?php wp_footer(); ?>
</body>

</html>
