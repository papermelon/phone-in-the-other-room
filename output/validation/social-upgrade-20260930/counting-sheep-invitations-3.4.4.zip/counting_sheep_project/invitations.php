<?php
/** Public invitation handoff. Never resolves private party details on the web. */
add_action('template_redirect', function () {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    if ($path === '/.well-known/apple-app-site-association' || $path === '/apple-app-site-association') {
        status_header(200);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        echo wp_json_encode(array('applinks' => array('details' => array(array(
            'appIDs' => array('4KZQPZR47B.com.ngawangchime.countingsheep'),
            'components' => array(array('/' => '/invite/*', 'comment' => 'Review a Slumber Party invitation')),
        )))));
        exit;
    }
    if (!is_string($path) || strpos($path, '/invite/') !== 0) {
        return;
    }
    $valid = preg_match('#^/invite/([A-HJ-NP-Z2-9]{12})$#D', $path, $match) === 1;
    status_header($valid ? 200 : 404);
    if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');
    header('Referrer-Policy: no-referrer');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    $code = $valid ? $match[1] : '';
    $cta = cs_get_app_primary_cta();
    ?>
    <!doctype html>
    <html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="referrer" content="no-referrer"><meta name="robots" content="noindex,nofollow">
    <title>Slumber Party invitation · Counting Sheep</title>
    <?php
    // Reuse the site branding without printing plugin scripts on invitation URLs.
    mytheme_enqueue_fonts();
    mytheme_enqueue_assets();
    wp_print_styles(array('nunito-font', 'mytheme-style'));
    ?>
    </head><body class="cs-invitation-page"><main class="cs-invitation">
      <div class="navbar-logo">
        <a href="<?php echo esc_url(home_url('/')); ?>" aria-label="Counting Sheep home">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo_with_text.png'); ?>"
               alt="Counting Sheep" width="1491" height="256">
        </a>
      </div>
      <p class="cs-kicker">Wind down together</p>
      <h1><?php echo $valid ? 'You’re invited to a Slumber Party' : 'This invitation link is incomplete'; ?></h1>
      <?php if ($valid) : ?>
      <p class="cs-invitation-lede">Put your phone to bed, together. A Slumber Party is a private group for you and people you know.</p>
      <p>Open Counting Sheep on your iPhone to review the invitation.</p>
      <a class="cs-button cs-button-primary" href="<?php echo esc_url('countingsheep://invite/' . $code, array('countingsheep')); ?>">Open invitation in app</a>
      <p class="cs-invitation-note">You’ll review the group and sharing details before choosing to join.</p>
      <section class="cs-invitation-code" aria-labelledby="invite-code-label">
        <p id="invite-code-label">Or use this invitation code in the app:</p>
        <div class="cs-invitation-code-row">
          <code id="invite-code"><?php echo esc_html($code); ?></code>
          <button class="cs-button" type="button" id="copy-code">Copy code</button>
        </div>
        <span id="copy-status" role="status" aria-live="polite"></span>
      </section>
      <?php else : ?>
      <p class="cs-invitation-lede">Ask the person inviting you to send the full link or the 12-character code.</p>
      <?php endif; ?>
      <footer class="cs-invitation-footer">
        <p>New to Counting Sheep?</p>
        <a class="cs-text-link" href="<?php echo esc_url($cta['url']); ?>" rel="noreferrer"><?php echo esc_html($cta['label']); ?></a>
        <?php if ($valid) : ?>
        <p class="cs-invitation-note">After installing, come back to this link or enter the code in Slumber Party.</p>
        <?php endif; ?>
        <p><a class="cs-text-link" href="<?php echo esc_url(home_url('/')); ?>">About Counting Sheep</a></p>
      </footer>
    </main>
    <?php if ($valid) : ?>
    <script>
      document.getElementById('copy-code').addEventListener('click', async () => {
        const code = document.getElementById('invite-code').textContent;
        try { await navigator.clipboard.writeText(code); document.getElementById('copy-status').textContent = 'Code copied.'; }
        catch { document.getElementById('copy-status').textContent = 'Select and copy the code above.'; }
      });
    </script>
    <?php endif; ?>
    </body></html>
    <?php
    exit;
}, 0);
